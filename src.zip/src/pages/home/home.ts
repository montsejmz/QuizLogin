import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AgregarPage } from '../agregar/agregar';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  usuario_r="";
  password_r="";
  usuarios=[];
  add=AgregarPage;




  constructor(public navCtrl: NavController) {

  }



  clickInicio(){

    let index =this.usuarios.findIndex(usuario => usuario.usuario == this.usuario_r && usuario.password == this.password_r)

    
  }

  clickAgregar(){

    /*this.usuarios.push({
      usuario:this.usuario_r,
      password:this.password_r
    })*/

    this.navCtrl.push(this.add, {usuarios: this.usuarios});
  }

}
